/* 
   Media dos alunos
*/

#include <stdio.h>
#include <stdlib.h>

float Media(float, float);

int main(){
    float A;
    scanf("%f", &A);
    printf("%f \n", A);
    
    float B;
    scanf("%f", &B);
    printf("%f\n", B);
    
    Media(A,B);
    
    system("pause");

    return 0;    
}

float Media(float A, float B){
      float C;
      C = (A + B) / 2;
      
      if(C>=6) printf("APROVADO \n");
      else printf("REPROVADO \n");             
}
